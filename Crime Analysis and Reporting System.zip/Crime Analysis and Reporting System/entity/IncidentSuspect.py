class IncidentSuspect:
    def __init__(self, IncidentId, SuspectId):
        self.__IncidentId = IncidentId
        self.__SuspectId = SuspectId

#getters:
    def getIncidentId(self):
        return self.__IncidentId
    
    def getSuspectId(self):
        return self.__SuspectId

#setters:
    def setIncidentId(self, IncidentId):
        self.__IncidentId = IncidentId

    def setSuspectId(self, SuspectId):
        self.__SuspectId = SuspectId
