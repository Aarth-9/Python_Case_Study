class Evidence:
    def __init__(self, EvidenceID, Description, Location_Found,
                IncidentID):
        self.__EvidenceID = EvidenceID
        self.__Description  = Description 
        self.__Location_Found = Location_Found
        self.__IncidentID = IncidentID

# Getters
    def getEvidenceID(self): 
        return self.__EvidenceID
    def getDescription(self): 
        return self.__Description
    def getLocation_Found(self): 
        return self.__Location_Found
    def getIncidentID(self): 
        return self.__IncidentID

# Setters
    def setEvidenceID(self, EvidenceID): 
        self.__EvidenceID = EvidenceID
    def setDescription(self, Description): 
        self.__Description = Description
    def setLocation_Found(self, Location_Found): 
        self.__Location_Found = Location_Found
    def setIncidentID(self, IncidentID): 
        self.__IncidentID = IncidentID
