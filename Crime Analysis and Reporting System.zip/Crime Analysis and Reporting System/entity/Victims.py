class Victims:
    def __init__(self, VictimID, FirstName, LastName, DateOfBirth,
                Gender, Address, Phone):
        self.__VictimID = VictimID
        self.__FirstName = FirstName
        self.__LastName = LastName
        self.__DateOfBirth = DateOfBirth
        self.__Gender = Gender
        self.__Address = Address
        self.__Phone = Phone

# Getters
    def getVictimID(self):
        return self.__VictimID

    def getFirstName(self):
        return self.__FirstName

    def getLastName(self):
        return self.__LastName

    def getDateOfBirth(self):
        return self.__DateOfBirth

    def getGender(self):
        return self.__Gender

    def getAddress(self):
        return self.__Address

    def getPhone(self):
        return self.__Phone

# Setters
    def setVictimID(self, VictimID):
        self.__VictimID = VictimID

    def setFirstName(self, FirstName):
        self.__FirstName = FirstName

    def setLastName(self, LastName):
        self.__LastName = LastName

    def setDateOfBirth(self, DateOfBirth):
        self.__DateOfBirth = DateOfBirth

    def setGender(self, Gender):
        self.__Gender = Gender

    def setAddress(self, Address):
        self.__Address = Address

    def setPhone(self, Phone):
        self.__Phone = Phone
