class IncidentVictim:
    def __init__(self, IncidentId, VictimId):
        self.__IncidentId = IncidentId
        self.__VictimId = VictimId

#getters:
    def getIncidentId(self):
        return self.__IncidentId
    
    def getVictimId(self):
        return self.__VictimId

#setters:
    def setIncidentId(self, IncidentId):
        self.__IncidentId = IncidentId

    def setVictimId(self, VictimId):
        self.__VictimId = VictimId