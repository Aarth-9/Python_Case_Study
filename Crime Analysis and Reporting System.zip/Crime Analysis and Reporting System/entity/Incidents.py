class Incidents:
    def __init__(self, IncidentID, IncidentType, IncidentDate, Location,
                Description, Status):
        self.__IncidentID = IncidentID
        self.__IncidentType = IncidentType
        self.__IncidentDate = IncidentDate
        self.__Location = Location
        self.__Description = Description
        self.__Status = Status
        self.__VictimIds = []     
        self.__SuspectIds = []   


#getters
    def getIncidentID(self):
        return self.__IncidentID

    def getIncidentType(self):
        return self.__IncidentType

    def getIncidentDate(self):
        return self.__IncidentDate

    def getLocation(self):
        return self.__Location

    def getDescription(self):
        return self.__Description

    def getStatus(self):
        return self.__Status
    
    def getVictimIds(self):
        return self.__VictimIds

    def getSuspectIds(self):
        return self.__SuspectIds

# Setters
    def setIncidentID(self, IncidentID):
        self.__IncidentID = IncidentID

    def setIncidentType(self, IncidentType):
        self.__IncidentType = IncidentType

    def setIncidentDate(self, IncidentDate):
        self.__IncidentDate = IncidentDate

    def setLocation(self, Location):
        self.__Location = Location

    def setDescription(self, Description):
        self.__Description = Description

    def setStatus(self, Status):
        self.__Status = Status

    def setVictimIds(self, VictimId):
        self.__VictimIds = VictimId

    def setSuspectIds(self, SuspectId):
        self.__SuspectIds = SuspectId