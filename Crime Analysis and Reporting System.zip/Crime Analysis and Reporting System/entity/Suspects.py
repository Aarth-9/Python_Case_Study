class Suspect:
    def __init__(self, SuspectID, FirstName, LastName, DateOfBirth,
                Gender, Address, Phone):
        self.__SuspectID = SuspectID
        self.__FirstName = FirstName
        self.__LastName = LastName
        self.__DateOfBirth = DateOfBirth
        self.__Gender = Gender
        self.__Address = Address
        self.__Phone = Phone

#getters
    def getSuspectID(self): 
        return self.__SuspectID

    def getFirstName(self): 
        return self.__FirstName

    def getLastName(self): 
        return self.__LastName

    def getDateOfBirth(self): 
        return self.__DateOfBirth

    def getGender(self): 
        return self.__Gender

    def getAddress(self): 
        return self.__Address

    def getPhone(self): 
        return self.__Phone
    
#setters  
    def setSuspectID(self, SuspectID): 
        self.__SuspectID = SuspectID

    def setFirstName(self, FirstName): 
        self.__FirstName = FirstName    

    def setLastName(self, LastName): 
        self.__LastName = LastName
    
    def setDateOfBirth(self, DateOfBirth): 
        self.__DateOfBirth = DateOfBirth
    
    def setGender(self, Gender): 
        self.__Gender = Gender
    
    def setAddress(self, Address): 
        self.__Address = Address
    
    def setPhone(self, Phone): 
        self.__Phone = Phone
