class Reports:
    def __init__(self, ReportID, IncidentID, ReportingOfficer,
                  ReportDate, ReportDetails, Status):
        self.__ReportID = ReportID
        self.__IncidentID = IncidentID
        self.__ReportingOfficer = ReportingOfficer
        self.__ReportDate = ReportDate
        self.__ReportDetails = ReportDetails
        self.__Status = Status
# Getters
    def getReportID(self): 
        return self.__ReportID
    def getIncidentID(self): 
        return self.__IncidentID
    def getReportingOfficer(self): 
        return self.__ReportingOfficer
    def getReportDate(self): 
        return self.__ReportDate
    def getReportDetails(self): 
        return self.__ReportDetails
    def getStatus(self): 
        return self.__Status

# Setters
    def setReportID(self, ReportID): 
        self.__ReportID = ReportID
    def setIncidentID(self, IncidentID): 
        self.__IncidentID = IncidentID
    def setReportingOfficer(self, ReportingOfficer): 
        self.__ReportingOfficer = ReportingOfficer
    def setReportDate(self, ReportDate): 
        self.__ReportDate = ReportDate
    def setReportDetails(self, ReportDetails): 
        self.__ReportDetails = ReportDetails
    def setStatus(self, Status): 
        self.__Status = Status
