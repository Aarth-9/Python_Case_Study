class Law_Enforcement_Agencies:
    def __init__(self, AgencyID, AgencyName, Jurisdiction, Address, Phone):
        self.__AgencyID = AgencyID
        self.__AgencyName = AgencyName
        self.__Jurisdiction = Jurisdiction
        self.__Address = Address
        self.__Phone = Phone

# Getters
    def getAgencyID(self): 
        return self.__AgencyID
    def getAgencyName(self): 
        return self.__AgencyName
    def getJurisdiction(self): 
        return self.__Jurisdiction
    def getAddress(self): 
        return self.__Address
    def getPhone(self): 
        return self.__Phone

# Setters
    def setAgencyID(self, AgencyID): 
        self.__AgencyID = AgencyID
    def setAgencyName(self, AgencyName): 
        self.__AgencyName = AgencyName
    def setJurisdiction(self, Jurisdiction): 
        self.__Jurisdiction = Jurisdiction
    def setAddress(self, Address): 
        self.__Address = Address
    def setPhone(self, Phone): 
        self.__Phone = Phone
