class Cases:
    def __init__(self, CaseID, caseDescription, Incidents):
        self.__CaseID = CaseID
        self.__caseDescription = caseDescription
        self.__Incidents = Incidents if Incidents is not None else []

#get case details
    def getCaseId(self):
        return self.__CaseID

    def getCaseDescription(self):
        return self.__caseDescription

    def getIncidents(self):
        return self.__Incidents
    
#set case details
    def setCaseId(self, CaseId):
        self.__CaseID = CaseId

    def setCaseDescription(self, caseDescription):
        self.__caseDescription = caseDescription

    def setIncidents(self, Incidents):
        self.__Incidents = Incidents

#utility methods
    def addIncident(self, Incident):
        self.__Incidents.append(Incident)

    def __str__(self):
        return f"Case[ID={self.__CaseID}, Description='{self.__caseDescription}', IncidentsCount={len(self.__Incidents)}]"

    def __repr__(self):
        return self.__str__()
