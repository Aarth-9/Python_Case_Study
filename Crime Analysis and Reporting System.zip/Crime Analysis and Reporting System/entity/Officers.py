class Officers:
    def __init__(self, OfficerID, FirstName, LastName,
                  BadgeNumber, Ranks, Address, Phone, AgencyID):
        self.__OfficerID = OfficerID
        self.__FirstName = FirstName
        self.__LastName = LastName
        self.__BadgeNumber = BadgeNumber
        self.__Ranks = Ranks
        self.__Address = Address
        self.__Phone = Phone
        self.__AgencyID = AgencyID

# Getters
    def getOfficerID(self): 
        return self.__OfficerID
    def getFirstName(self): 
        return self.__FirstName
    def getLastName(self): 
        return self.__LastName
    def getBadgeNumber(self): 
        return self.__BadgeNumber
    def getRanks(self): 
        return self.__Ranks
    def getAddress(self): 
        return self.__Address
    def getPhone(self): 
        return self.__Phone
    def getAgencyID(self): 
        return self.__AgencyID

# Setters
    def setOfficerID(self, OfficerID): 
        self.__OfficerID = OfficerID
    def setFirstName(self, FirstName): 
        self.__FirstName = FirstName
    def setLastName(self, LastName): 
        self.__LastName = LastName
    def setBadgeNumber(self, BadgeNumber): 
        self.__BadgeNumber = BadgeNumber
    def setRanks(self, Ranks): 
        self.__Ranks = Ranks
    def setAddress(self, Address): 
        self.__Address = Address
    def setPhone(self, Phone): 
        self.__Phone = Phone
    def setAgencyID(self, AgencyID): 
        self.__AgencyID = AgencyID