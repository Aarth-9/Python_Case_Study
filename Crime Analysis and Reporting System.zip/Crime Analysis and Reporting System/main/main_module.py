import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from dao.crime_analysis_impl import CrimeAnalysisServiceImpl
from entity.Incidents import Incidents
from entity.Case import Cases

def main():
    service = CrimeAnalysisServiceImpl()

    while True:
        print("\n=== Crime Analysis System ===")
        print("1. Create Incident")
        print("2. Update Incident Status")
        print("3. Get Incidents in Date Range")
        print("4. Search Incidents by Type")
        print("5. Generate Incident Report")
        print("6. Create Case")
        print("7. Get Case Details")
        print("8. Update Case Description")
        print("9. Get All Cases")
        print("10. Visualize Crime Trend")
        print("0. Exit")
        
        choice = input("Enter your choice: ")

        if choice == "1":
            incident_type = input("Enter Incident Type: ")
            date = input("Enter Incident Date (YYYY-MM-DD): ")
            location = input("Enter Location (place or latitude & longitude): ")
            description = input("Enter Description: ")
            status = input("Enter Status (Open/Closed): ")
            victim_ids = list(map(int, input("Enter Victim IDs (comma-separated): ").split(',')))
            suspect_ids = list(map(int, input("Enter Suspect IDs (comma-separated): ").split(',')))

            incident = Incidents(None, incident_type, date, location, description, status)
            incident.setVictimIds(victim_ids)
            incident.setSuspectIds(suspect_ids)

            success = service.create_incident(incident)
            print("Incident Created:", success)

        elif choice == "2":
            incident_id = int(input("Enter Incident ID to update: "))
            new_status = input("Enter new status (Open/Closed): ")
            updated = service.update_incident_status(new_status, incident_id)
            print("Incident Status Updated:", updated)

        elif choice == "3":
            start_date = input("Enter Start Date (YYYY-MM-DD): ")
            end_date = input("Enter End Date (YYYY-MM-DD): ")
            incidents = service.get_incidents_in_date_range(start_date, end_date)
            print("Incidents in Range:", incidents)

        elif choice == "4":
            search_type = input("Enter Incident Type to Search: ")
            results = service.search_incidents(search_type)
            print("Incidents Found:", results)

        elif choice == "5":
            incident_id = int(input("Enter Incident ID to Generate Report: "))
            officer_id = int(input("Enter Reporting Officer ID: "))
            incident = service.get_incident_by_id(incident_id)
            if incident:
                report = service.generate_incident_report(incident, officer_id)
                print("Incident Report:", report)
            else:
                print("Incident not found.")

        elif choice == "6":
            description = input("Enter Case Description: ")
            incident_ids = list(map(int, input("Enter Incident IDs for the case (comma-separated): ").split(',')))
            incidents = [service.get_incident_by_id(iid) for iid in incident_ids if service.get_incident_by_id(iid)]
            case = service.create_case(description, incidents)
            print("Case Created:", case)

        elif choice == "7":
            case_id = int(input("Enter Case ID: "))
            details = service.get_case_details(case_id)
            print("Case Details:", details)

        elif choice == "8":
            case_id = int(input("Enter Case ID to Update: "))
            case = service.get_case_details(case_id)
            if case:
                new_desc = input("Enter New Description: ")
                case.setCaseDescription(new_desc)
                updated = service.update_case_details(case)
                print("Case Updated:", updated)
            else:
                print("Case not found.")

        elif choice == "9":
            cases = service.get_all_cases()
            print("All Cases:", cases)

        elif choice == "10":
            print("Generating crime trend visualization...")
            service.visualize_incident_type_by_status()

        elif choice == "0":
            print("Exiting...")
            break

        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
