import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from dao.crime_analysis_impl import CrimeAnalysisServiceImpl
from entity.Incidents import Incidents
from entity.Case import Cases
from entity.IncidentSuspect import IncidentSuspect
from entity.IncidentVictim import IncidentVictim

# Sample main module
def main():
    service = CrimeAnalysisServiceImpl()

    # Create Incident Example
    incident = Incidents(
        IncidentID=None,  
        IncidentType="Robbery",
        IncidentDate="2025-06-20",
        Location="12.9716,77.5946",
        Description="Robbery at MG Road",
        Status="Open"
    )

    # Manually manage victim and suspect lists for DB insert later
    victim_ids = [1, 2]
    suspect_ids = [3]

    # Set victims and suspects to the incident object via methods or direct assignment
    incident.setVictimIds(victim_ids)
    incident.setSuspectIds(suspect_ids)

    # Create Incident
    success = service.create_incident(incident)
    print("Incident Created:", success)

    # Update Incident Status
    updated = service.update_incident_status("Closed", 1)
    print("Incident Status Updated:", updated)

    # Get Incidents in Date Range
    incidents = service.get_incidents_in_date_range("2025-06-01", "2025-06-30")
    print("Incidents in Range:", incidents)

    # Search Incidents by Type
    robbery_incidents = service.search_incidents("Robbery")
    print("Robbery Incidents:", robbery_incidents)

    # Generate Report
    report = service.generate_incident_report(incident)
    print("Incident Report:", report)

    # Create Case
    case = service.create_case("Robbery case in June", [incident])
    print("Case Created:", case)

    # Get Case Details
    case_details = service.get_case_details(case.getCaseId()) if case else None
    print("Case Details:", case_details)

    # Update Case Description
    if case:
        case.setCaseDescription("Updated Robbery case")
        update_success = service.update_case_details(case)
        print("Case Updated:", update_success)

    # Get All Cases
    all_cases = service.get_all_cases()
    print("All Cases:", all_cases)

    print("\nGenerating crime trend visualization...")
    service.visualize_incident_type_by_status()


if __name__ == "__main__":
    main()
