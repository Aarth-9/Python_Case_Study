#python3 -m unittest test.test_crime_analysis

import unittest
from dao.crime_analysis_impl import CrimeAnalysisServiceImpl
from entity.Incidents import Incidents
from entity.Case import Cases
from entity.IncidentSuspect import IncidentSuspect
from entity.IncidentVictim import IncidentVictim

class TestCrimeAnalysisService(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.service = CrimeAnalysisServiceImpl()

    def test_create_incident(self):
        incident = Incidents(
            IncidentID=None,
            IncidentType="TestTheft",
            IncidentDate="2025-06-24",
            Location="13.0827,80.2707",
            Description="Test theft incident",
            Status="Open"
        )
        incident.setVictimIds([1])
        incident.setSuspectIds([2])
        result = self.service.create_incident(incident)
        self.assertTrue(result)

    def test_update_incident_status(self):
        result = self.service.update_incident_status("Closed", 1)
        self.assertTrue(result)

    def test_get_incidents_in_date_range(self):
        results = self.service.get_incidents_in_date_range("2025-06-01", "2025-06-30")
        self.assertIsInstance(results, list)

    def test_search_incidents(self):
        results = self.service.search_incidents("TestTheft")
        self.assertIsInstance(results, list)

    def test_generate_incident_report(self):
        incident = Incidents(1, "TestTheft", "2025-06-24", "13.0827,80.2707", "Test theft", "Open")
        incident.setVictimIds([1])
        incident.setSuspectIds([2])
        report = self.service.generate_incident_report(incident)
        self.assertIn("IncidentID", report)

    def test_create_case(self):
        incident = Incidents(1, "TestTheft", "2025-06-24", "13.0827,80.2707", "Test theft", "Open")
        case = self.service.create_case("Test case description", [incident])
        self.assertIsNotNone(case)

    def test_get_case_details(self):
        case_details = self.service.get_case_details(1)
        self.assertIsNotNone(case_details)

    def test_update_case_details(self):
        case = Cases(1, "Updated Test Case", [])
        result = self.service.update_case_details(case)
        self.assertTrue(result)

    def test_get_all_cases(self):
        results = self.service.get_all_cases()
        self.assertIsInstance(results, list)

if __name__ == '__main__':
    unittest.main()
