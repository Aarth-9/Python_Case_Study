def get_property_string(filename):
    properties = {}

    try:
        with open(filename, 'r') as file:
            for line in file:
                line = line.strip()
                if line and not line.startswith('#'):
                    key, value = line.split('=', 1)
                    properties[key.strip()] = value.strip()

        host = properties.get('host')
        database = properties.get('database')
        user = properties.get('user')
        password = properties.get('password')
        port = properties.get('port', '3306')

        return {
            'host': host,
            'database': database,
            'user': user,
            'password': password,
            'port': port
        }

    except FileNotFoundError:
        print(f"Properties file '{filename}' not found.")
        return None
    except Exception as e:
        print(f"Error reading properties: {e}")
        return None