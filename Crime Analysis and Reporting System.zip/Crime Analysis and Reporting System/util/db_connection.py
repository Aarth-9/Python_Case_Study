import mysql.connector
from util.property_util import get_property_string

class DBConnection:
    __connection = None

    @staticmethod
    def get_connection():
        if DBConnection.__connection is None:
            props = get_property_string('db.properties')
            if props:
                try:
                    DBConnection.__connection = mysql.connector.connect(
                        host=props['host'],
                        database=props['database'],
                        user=props['user'],
                        password=props['password'],
                        port=props['port']
                    )
                    print(" Database connection established.")
                except mysql.connector.Error as err:
                    print(f" Error connecting to database: {err}")
        return DBConnection.__connection
