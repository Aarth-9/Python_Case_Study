class IncidentNumberNotFoundException(Exception):
    def __init__(self, message="Incident number not found in the database."):
        super().__init__(message)
