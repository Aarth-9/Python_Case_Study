class IncidentStatusUpdateException(Exception):
    def __init__(self, message="Incident status update failed."):
        super().__init__(message)
