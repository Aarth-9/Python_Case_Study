class CaseUpdateException(Exception):
    def __init__(self, message="Failed to update case."):
        super().__init__(message)