class IncidentFetchException(Exception):
    def __init__(self, message="Unable to fetch incident data."):
        super().__init__(message)
