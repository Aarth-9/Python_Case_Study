class CaseCreationException(Exception):
    def __init__(self, message="Case creation failed."):
        super().__init__(message)