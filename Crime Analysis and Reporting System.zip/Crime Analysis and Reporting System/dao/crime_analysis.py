from abc import ABC, abstractmethod

class ICrimeAnalysisService(ABC):

    @abstractmethod
    def create_incident(self, incident):
        pass

    @abstractmethod
    def update_incident_status(self, status, incident_id):
        pass

    @abstractmethod
    def get_incidents_in_date_range(self, start_date, end_date):
        pass

    @abstractmethod
    def search_incidents(self, incident_type):
        pass

    @abstractmethod
    def generate_incident_report(self, incident):
        pass

    @abstractmethod
    def create_case(self, description, incidents):
        pass

    @abstractmethod
    def get_case_details(self, case_id):
        pass

    @abstractmethod
    def update_case_details(self, case_obj):
        pass

    @abstractmethod
    def get_all_cases(self):
        pass