import mysql.connector
import pandas as pd
from datetime import date
import matplotlib.pyplot as plt
from dao.crime_analysis import ICrimeAnalysisService
from util.db_connection import DBConnection
from c.myexceptions.incident_not_found_exception import IncidentNumberNotFoundException
from c.myexceptions.incident_status_update_exception import IncidentStatusUpdateException
from c.myexceptions.case_creation_exception import CaseCreationException
from entity.Case import Cases
from entity.Incidents import Incidents

class CrimeAnalysisServiceImpl(ICrimeAnalysisService):

    def __init__(self):
        self.connection = DBConnection.get_connection()
        self.cursor = self.connection.cursor()

    def create_incident(self, incident):
        try:
            query = """
            INSERT INTO Incidents (IncidentType, IncidentDate, Location, Description, Status)
            VALUES (%s, %s, %s, %s, %s)
            """
            data = (
                incident.getIncidentType(),
                incident.getIncidentDate(),
                incident.getLocation(),
                incident.getDescription(),
                incident.getStatus()
            )
            self.cursor.execute(query, data)
            incident_id = self.cursor.lastrowid
            incident.setIncidentID(incident_id)

            # Insert into IncidentVictim and IncidentSuspect tables
            for victim_id in incident.getVictimIds():
                self.cursor.execute("INSERT INTO IncidentVictims (IncidentId, VictimId) VALUES (%s, %s)", (incident_id, victim_id))

            for suspect_id in incident.getSuspectIds():
                self.cursor.execute("INSERT INTO IncidentSuspects (IncidentId, SuspectId) VALUES (%s, %s)", (incident_id, suspect_id))

            self.connection.commit()
            return True
        except Exception as e:
            print("Error inserting incident:", e)
            return False

    def update_incident_status(self, status, incident_id):
        try:
            query = "UPDATE Incidents SET Status = %s WHERE IncidentID = %s"
            self.cursor.execute(query, (status, incident_id))

            if self.cursor.rowcount == 0:
                self.cursor.execute("SELECT * FROM Incidents WHERE IncidentID = %s", (incident_id,))
                if not self.cursor.fetchone():
                    raise IncidentNumberNotFoundException("Incident ID not found.")
                else:
                    raise IncidentStatusUpdateException("Incident exists, but status already the same.")

            self.connection.commit()
            return True
        except (IncidentNumberNotFoundException, IncidentStatusUpdateException) as e:
            print(e)
            return False
        except Exception as e:
            print("Error updating incident status:", e)
            return False

    def get_incidents_in_date_range(self, start_date, end_date):
        try:
            query = "SELECT * FROM Incidents WHERE IncidentDate BETWEEN %s AND %s"
            self.cursor.execute(query, (start_date, end_date))
            return self.cursor.fetchall()
        except Exception as e:
            print("Error fetching incidents:", e)
            return []

    def search_incidents(self, incident_type):
        try:
            query = "SELECT * FROM Incidents WHERE IncidentType = %s"
            self.cursor.execute(query, (incident_type,))
            return self.cursor.fetchall()
        except Exception as e:
            print("Error searching incidents:", e)
            return []
        
    def get_incident_by_id(self, incident_id):
        try:
            cursor = self.connection.cursor()
            cursor.execute("SELECT * FROM Incidents WHERE IncidentID = %s", (incident_id,))
            row = cursor.fetchone()
            if row:
                # Assuming order: IncidentID, IncidentType, IncidentDate, Location, Description, Status
                return Incidents(
                    IncidentID=row[0],
                    IncidentType=row[1],
                    IncidentDate=str(row[2]),
                    Location=row[3],
                    Description=row[4],
                    Status=row[5]
                )
            else:
                return None
        except Exception as e:
            print("Error fetching incident:", e)
            return None
        finally:
            cursor.close()

    # def generate_incident_report(self, incident):
    #     try:
    #         return {
    #             "IncidentID": incident.getIncidentID(),
    #             "Type": incident.getIncidentType(),
    #             "Date": incident.getIncidentDate(),
    #             "Location": incident.getLocation(),
    #             "Description": incident.getDescription(),
    #             "Status": incident.getStatus(),
    #             "Victims": incident.getVictimIds(),
    #             "Suspects": incident.getSuspectIds()
    #         }
    #     except Exception as e:
    #         print("Error generating report:", e)
    #         return {}

    def generate_incident_report(self, incident, officer_id=401):  
        report_text = (
            f"Incident Report:\n"
            f"----------------\n"
            f"Incident ID: {incident.getIncidentID()}\n"
            f"Type: {incident.getIncidentType()}\n"
            f"Date: {incident.getIncidentDate()}\n"
            f"Location: {incident.getLocation()}\n"
            f"Description: {incident.getDescription()}\n"
            f"Status: {incident.getStatus()}\n"
        )

        print("\n" + report_text)

        cursor = None
        try:
            cursor = self.conn.cursor()

            insert_sql = """
                INSERT INTO Reports (IncidentID, ReportingOfficer, ReportDate, ReportDetails, Status)
                VALUES (%s, %s, %s, %s, %s)
            """
            values = (
                incident.getIncidentID(),
                officer_id,                
                date.today(),              
                incident.getDescription(),               
                incident.getStatus()       
            )

            cursor.execute(insert_sql, values)
            self.conn.commit()
            print("Report successfully inserted into the Reports table.")
        except Exception as e:
            print("Error inserting report:", e)
        finally:
            if cursor:
                cursor.close()

        return report_text
    def create_case(self, description, incidents):
        try:
            query = "INSERT INTO Cases (Description) VALUES (%s)"
            self.cursor.execute(query, (description,))
            case_id = self.cursor.lastrowid

            for incident in incidents:
                self.cursor.execute(
                    "INSERT INTO CaseIncident (CaseID, IncidentID) VALUES (%s, %s)",
                    (case_id, incident.getIncidentID())
                )
            self.connection.commit()
            return Cases(case_id, description, incidents)
        except Exception as e:
            raise CaseCreationException(f"Case creation failed due to: {e}")

    def get_case_details(self, case_id):
        try:
            self.cursor.execute("SELECT * FROM Cases WHERE CaseID = %s", (case_id,))
            row = self.cursor.fetchone()
            if row:
                self.cursor.execute("SELECT IncidentID FROM CaseIncident WHERE CaseID = %s", (case_id,))
                incident_ids = [r[0] for r in self.cursor.fetchall()]
                incidents = []
                for inc_id in incident_ids:
                    self.cursor.execute("SELECT * FROM Incidents WHERE IncidentID = %s", (inc_id,))
                    inc_row = self.cursor.fetchone()
                    if inc_row:
                        incidents.append(Incidents(*inc_row))
                return Cases(row[0], row[1], incidents)
            return None
        except Exception as e:
            print("Error fetching case details:", e)
            return None

    def update_case_details(self, case_obj):
        try:
            query = "UPDATE Cases SET Description = %s WHERE CaseID = %s"
            self.cursor.execute(query, (case_obj.getCaseDescription(), case_obj.getCaseId()))
            self.connection.commit()
            return True
        except Exception as e:
            print("Error updating case:", e)
            return False

    def get_all_cases(self):
        try:
            self.cursor.execute("SELECT * FROM Cases")
            rows = self.cursor.fetchall()
            all_cases = []
            for row in rows:
                case_id = row[0]
                description = row[1]
                self.cursor.execute("SELECT IncidentID FROM CaseIncident WHERE CaseID = %s", (case_id,))
                incident_ids = [r[0] for r in self.cursor.fetchall()]
                incidents = []
                for inc_id in incident_ids:
                    self.cursor.execute("SELECT * FROM Incidents WHERE IncidentID = %s", (inc_id,))
                    inc_row = self.cursor.fetchone()
                    if inc_row:
                        incidents.append(Incidents(*inc_row))
                all_cases.append(Cases(case_id, description, incidents))
            return all_cases
        except Exception as e:
            print("Error retrieving cases:", e)
            return []

    def visualize_incident_type_by_status(self):
        try:
            query = """
                SELECT IncidentType, Status
                FROM Incidents
            """
            self.cursor.execute(query)
            records = self.cursor.fetchall()

            if not records:
                print("No incident data available for visualization.")
                return

            # Convert to DataFrame
            df = pd.DataFrame(records, columns=["IncidentType", "Status"])

            # Group by IncidentType and Status
            grouped = df.groupby(['IncidentType', 'Status']).size().unstack(fill_value=0)

            # Plotting stacked bar chart
            grouped.plot(kind='bar', stacked=True, figsize=(10, 6), colormap='Set2')

            plt.title("Incident Type by Status")
            plt.xlabel("Incident Type")
            plt.ylabel("Number of Incidents")
            plt.xticks(rotation=45)
            plt.legend(title="Status")
            plt.tight_layout()
            plt.show()

        except Exception as e:
            print("Error generating visualization:", e)
